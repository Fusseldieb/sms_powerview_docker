SHELL=/bin/sh

# 
# SMS Alerta 24 Horas - www.alerta24h.com.br
# Script para levantamento de informacoes
#
# Este script deve ser copiado no diretorio raiz de instalacao
# do software SMS PowerView e executado como usuario root.
#
# Antes da execucao deve=se atentar as seguintes informacoes:
# 
# 1- Um nobreak de comunicacao USB deve estar devidamente conectado.
# 2- O PowerView NAO deve estar em execucao
# 3- Deve-se atribuir a permissao +x para execucao do script
#
# 0.2
#

# Data e hora
DATA=`date +%Y.%m.%d_%H-%M`
echo $DATA

# Diretorio de instalacao do powerview
SMSPV=`pwd`
echo $SMSPV

# Insere uma nova linha no arquivo de log
novaLinha(){
	echo "" 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	echo "" 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
}

# Verificação de informacoes do cliente, permissoes e SO
verificaUsuario(){
	cd $SMSPV

	novaLinha
	echo "vertificaUsuario() --- Verificacao do usuario -----------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	whoami 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "vertificaUsuario() --- Listando permisao de diretorio ---------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	ls -l ../ 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "vertificaUsuario() --- Listando permissao no diretorio do Power View ------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	ls -l 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "vertificaUsuario() --- Listando informacoes do SO 1 -----------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	uname -a 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	
	novaLinha
	echo "vertificaUsuario() --- Listando informacoes do SO 2 -----------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	cat /etc/issue 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
}

# Verificação da comunicação com a porta 8080
verificaComm(){
	novaLinha
	echo "verificaPorta() --- Verificando o uso da porta ----------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	lsof -i:8080 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
}

# Coleta informações sobre o powerview instalado
verificaPowerView(){
	novaLinha
	echo "verificaPowerView() --- Verificando dados do Power View -------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	cd $SMSPV
	pwd 2>>sms_tmpread.log 1>>sms_tmpread.log

	echo "Versao" 2>>sms_tmpread.log 1>>sms_tmpread.log
	./powerview -v 2>>sms_tmpread.log 1>> sms_tmpread.log

	echo "Status" 2>>sms_tmpread.log 1>>sms_tmpread.log
	./powerview status 2>> sms_tmpread.log 1>>sms_tmpread.log

	echo "Porta" 2>>sms_tmpread.log 1>>sms_tmpread.log
	./powerview -t 2>> sms_tmpread.log 1>>sms_tmpread.log
	cd ..

	cat $SMSPV/sms_tmpread.log 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	rm $SMSPV/sms_tmpread.log 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
}

# Coleta informações sobre o java
verificaJava(){
	novaLinha
	echo "verificaJava() --- Versao java  -------------------------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	java -version 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "verificaJava() --- Versao javac  ------------------------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	javac -version 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "verificaJava() --- Which java ---------------------------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	which java 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "verificaJava() --- Which javac --------------------------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	which javac 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "verificaJava() --- echo JAVA_HOME -----------------------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	echo $JAVA_HOME 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "verificaJava() --- echo PATH ----------------------------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	echo $PATH 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
}

# Levanta informações sobre acesso telnet e wget
verificaAcessos(){
	novaLinha
	echo "verificaAcessos() --- Acesso http Power View [wget] -----------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	wget -T 3 localhost:8080/sms 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	echo "verificaAcessos() --- Acesso ao Alerta: HTTPS..." 
	wget -T 3 https://www.alerta24h.com.br/a24h 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "verificaAcessos() --- Acesso http Power View [Telnet] ---------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	echo "help close" | telnet localhost 8080 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
}

# Verifica as configurações do dispositivo USB
verificaConfUSB(){
	novaLinha
	echo "verificaConfUSB() --- Verifica a existência do link simbolico -------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	if [ -f /teste/arquivo ]; then
		echo "Existe" 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log;
	else
		echo "Nao existe" 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log;
	fi

	novaLinha
	echo "verificaConfUSB() --- Verifica link simbolico para USB --------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	i=0;
	while [ $i != "3" ];
	do
		if [ -e /dev/ttyUSB$i ]; then
			echo "Detectado" $i 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
		else
			echo "Nao detectado" $i 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
		fi
		i=$[i+1];
	done

	novaLinha
	echo "verificaConfUSB() --- Lista portas USB ------------------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	ls -l /dev/ttyUSB* 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log

	novaLinha
	echo "verificaConfUSB() --- Verificando modulo cypress --------------------------" 2>> smsLog_"$DATA".log 1>>smsLog_"$DATA".log
	lsmod | grep cypress 2>>smsLog_"$DATA".log 1>>smsLog_"$DATA".log
}

# Exibe mensagem finalizando o script
menagemFinal(){
	echo ""
	echo "Pronto."
	echo ""
	echo "Script finalizado. Favor enviar o arquivo" smsLog_"$DATA".log "."
	echo ""
}

# Executa 
executa(){
	TOTAL=6
	step=1

	echo $step"/"$TOTAL " Levantando informacoes do ambiente..."
	verificaUsuario

	step=$[step+1];

	echo $step"/"$TOTAL " Levantando informacoes de comunicacao..."
	verificaComm

	step=$[step+1];

	echo $step"/"$TOTAL " Verificando a JVM..."
	verificaJava

	step=$[step+1];

	echo $step"/"$TOTAL " Verificando acessos..."
	verificaAcessos

	step=$[step+1];

	echo $step"/"$TOTAL " Verificando configuracoes USB..."
	verificaConfUSB

	step=$[step+1];

	echo $step"/"$TOTAL " Verificando SMS Power View..."
	verificaPowerView

	menagemFinal
}

#
# Incio execucao
#

executa
