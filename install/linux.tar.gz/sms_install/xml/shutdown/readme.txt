Execute o aplicativo shut.exe

Ele gerará dois arquivos de log:
2) sms_geral.log -> Guarda dat,hora e nomes dos processos ...

Obs.: O arquivo path.sht contém o caminho dos arquivos de log. Não esquecer de manter no final a barra invertida '\'.