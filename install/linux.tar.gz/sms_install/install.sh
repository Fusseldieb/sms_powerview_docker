#!/bin/sh

#BASEDIR_INSTALL=$(dirname $0)
BASEDIR_INSTALL=$( cd "$( dirname "$0" )" && pwd )

local_instalacao(){
STRING_VAZIO=
 if [ "$JAVA_HOME" = "$STRING_VAZIO" ]
 then
  echo "Informe onde o JAVA está instalado. EX: /usr/lib/jvm/java-6-sun"
  read JAVA_HOME
 fi


if [ ! -d $JAVA_HOME ]
 then
  echo "O diretório informado não existe:[$JAVA_HOME]"
  exit 1
 fi
 echo "O SMS Power View  utilizará o JAVA instalado em:$JAVA_HOME"
 echo ""
 echo "Informe o valor da variável DISPLAY. Pressione <ENTER> para assumir valor default ["'$DISPLAY'"=$DISPLAY]:"
 read VAR_DISPLAY
 STRING_VAZIO=
 if [ "$VAR_DISPLAY" = "$STRING_VAZIO" ]
 then
  VAR_DISPLAY=$DISPLAY
 fi

 read -p "Informe o diretorio de instalacao do powerview [/opt/powerview]: " LOCAL_INSTALACAO

#diretiva para parar ao primeiro erro.
#set -e

 if [ -z "$LOCAL_INSTALACAO" ]; then
  LOCAL_INSTALACAO=/opt/powerview
 fi

 clear
 pronto
}

pronto(){
 while :
  do
        echo "Configurar SMS POWERVIEW LINUX em $LOCAL_INSTALACAO (s/n)?"
         read PRONTO_PARA_INSTALAR

      case $PRONTO_PARA_INSTALAR in
         s) clear
      instalar
      exit 1;;
         n) clear
      exit 1;;
         *) clear
      pronto;;
   esac
 done
}

instalar(){

if [ ! -d "$LOCAL_INSTALACAO" ];  then
  mkdir "$LOCAL_INSTALACAO"
fi

cp $BASEDIR_INSTALL/*.p12 "$LOCAL_INSTALACAO"/
cp $BASEDIR_INSTALL/log4j.properties "$LOCAL_INSTALACAO"/

mkdir "$LOCAL_INSTALACAO"/banco


mkdir "$LOCAL_INSTALACAO"/images
cp -R $BASEDIR_INSTALL/images/* "$LOCAL_INSTALACAO"/images/

mkdir "$LOCAL_INSTALACAO"/xml
cp -R $BASEDIR_INSTALL/xml/* "$LOCAL_INSTALACAO"/xml/

mkdir "$LOCAL_INSTALACAO"/resource
cp -R $BASEDIR_INSTALL/resource/* "$LOCAL_INSTALACAO"/resource/

ln -s "$LOCAL_INSTALACAO"/xml/info.sh "$LOCAL_INSTALACAO"/info
chmod +x "$LOCAL_INSTALACAO"/info

mkdir "$LOCAL_INSTALACAO"/libs
cp -R $BASEDIR_INSTALL/libs/* "$LOCAL_INSTALACAO"/libs/


mkdir "$LOCAL_INSTALACAO"/logs
mkdir "$LOCAL_INSTALACAO"/logs/arquivos
mkdir "$LOCAL_INSTALACAO"/logs/arquivos/Dados
mkdir "$LOCAL_INSTALACAO"/logs/arquivos/Eventos
mkdir "$LOCAL_INSTALACAO"/logs/sistema

mkdir "$LOCAL_INSTALACAO"/webserver
cp -R $BASEDIR_INSTALL/webserver/* "$LOCAL_INSTALACAO"/webserver/

 
 echo "Gerando scripts de instalacao..."
 echo ""
 echo "Gerando powerview em $LOCAL_INSTALACAO"
POWERVIEWONE=`echo "#!/bin/bash
########################################################################
# O SMS Power View é um software de gerenciamento de energia que       #
# apresenta as condições de funcionamento do nobreak e da rede         #
# elétrica, realizando tarefas específicas.                            #
#     	                        				       #
# 			  Personalizar Configurações                   #
#								       #
# Para personalizar as suas configurações basta substituir os valores  #
# de GUI_DEFAULT e DEBUG_DEFAULT para:				       #
#								       #
# GUI_DEFAULT=0        - INICIO SEM MODO GRAFICO                       #
# GUI_DEFAULT=1        - INICIO COM MODO GRAFICO                       #
# DEBUG_DEFAULT=0      - INICIO SEM DEBUG                              # 
# DEBUG_DEFAULT=1      - INICIO COM DEBUG                              #  
########################################################################

# Valor default para inicialização do modo grafico
GUI_DEFAULT=\"0\";              
               
# Valor default para inicialização do modo debug
DEBUG_DEFAULT=\"0\";

# Ativa(1) ou Desativa (0) a opção de inicializar o SMS Power View ao executar o comando: ./powerview
# Executando o comando ./powerview, caso esta opção esteja ativada, o powerview será inicializado com as opções default.
# Caso contrário, ao executar o comando ./powerview, a tela de help será exibida.
ATIVO=\"0\";

export PW_HOME=\"\$LOCAL_INSTALACAO\"
export JAVA_HOME=\"$JAVA_HOME\"
export DISPLAY=:0.0
export PATH=\$JAVA_HOME/bin:\$PATH

export WEBSERVER_CLASSPATH=webserver/libs/:webserver/libs/catalina-optional.jar:webserver/libs/catalina.jar:webserver/libs/commons-digester.jar:webserver/libs/commons-el.jar:webserver/libs/commons-logging-1.1.1.jar:webserver/libs/commons-modeler-2.0.1.jar:webserver/libs/commons-validator.jar:webserver/libs/jasper-compiler-jdt.jar:webserver/libs/jasper-compiler.jar:webserver/libs/jasper-runtime.jar:webserver/libs/jsp-api.jar:webserver/libs/naming-factory.jar:webserver/libs/naming-resources.jar:webserver/libs/servlet-api.jar:webserver/libs/servlets-default.jar:webserver/libs/tomcat-coyote.jar:webserver/libs/tomcat-http.jar:webserver/libs/tomcat-juli.jar:webserver/libs/tomcat-util.jar:webserver/libs/org.restlet.ext.xml-2.0-SNAPSHOT.jar:webserver/libs/org.restlet.ext.xstream-2.0-SNAPSHOT.jar:webserver/libs/org.restlet-2.0-SNAPSHOT.jar:webserver/libs/xstream-1.3.1.jar
export PW_CLASSPATH=resource/:libs/:libs/axis.jar:libs/comm.jar:libs/jackson-core-asl-1.9.2.jar:libs/jackson-mapper-asl-1.9.2.jar:libs/commons-beanutils.jar:libs/commons-collections.jar:libs/commons-discovery.jar:libs/commons-logging.jar:libs/comunicacao.jar:libs/proxyconsumed.jar:libs/db4o.jar:libs/GerenciaMail.jar:libs/jakarta-oro.jar:libs/jaxrpc.jar:libs/log4j-1.2.8.jar:libs/mail.jar:libs/pv_cliente_desktop.jar:libs/pv_servidor.jar:libs/commons-lang3-3.4.jar:libs/hidapi.jar:libs/jssc-2.8.0.jar:libs/struts.jar:libs/tray.jar:libs/bsh-2.0b2.jar:libs/jdom.jar:libs/commons-httpclient-3.0.1.jar:libs/commons-codec-1.5.jar:libs/apns-0.1.5-jar-with-dependencies.jar
export CONSOLE_CLASSPATH=resource/:libs/log4j-1.2.8.jar:libs/pv_cliente_desktop.jar:libs/comunicacao.jar:libs/proxyconsumed.jar:libs/pv_servidor.jar:libs/hidapi.jar:libs/commons-lang3-3.4.jar"`
if uname -m | grep '64' ; then  
	POWERVIEWTWO=`echo "$POWERVIEWONE 
	export PW_DLL=.:libs/:libs/64/"`
else   
    POWERVIEWTWO=`echo "$POWERVIEWONE
	export PW_DLL=.:libs/:libs/32/"`
fi 

echo "$POWERVIEWTWO
NOME_APP=\"SMS Power View\";

cd \"\$PW_HOME\";

#Função start do powerview
start(){
	if  [ \"\$GUI\" = \"1\" ]
	 then
	   trayIcon;
	  else
	   servico;
	fi
}

servico(){

if [ -e \"\$PW_HOME\"/SMSPowerView.tmp ]
  then
    echo \"\";
    echo \"O SMS Power View já está em execução.\";
    echo ;
  else
    echo \"Iniciando como Serviço...\";
    cd \"\$PW_HOME\"
    


i=0;
j=8;
while [ \$i != \"3\" ]
do

if [ -e /dev/ttyUSB\$i ]; then
       echo Criando link simbolico para USB-Serial.
       ln -sf /dev/ttyUSB\$i /dev/ttyS\$j
		stty -F /dev/ttyUSB\$i -brkint -icrnl -imaxbel -opost -onlcr -isig -icanon -iexten -echo -echoe -echok -echoctl;max=0;min=0;time=0;line=0 
       j=\$[j+1]; 
fi

    i=\$[i+1];

done

    rm -f output.log
	
    
    java -noverify -Djava.library.path=\$PW_DLL -cp \"\$PW_CLASSPATH\":\"\$WEBSERVER_CLASSPATH\"  br.com.sms.powerview.servico.SMSysServico \$DEBUG & 

        
    echo \"SMS Power View iniciado com sucesso.\";
fi

}




trayIcon(){

if [ -e \"\$PW_HOME\"/SMSPowerView.tmp ]
  then
    echo \"\";
    echo \"O SMS Power View já está em execução.\";
    echo \"\";
  else
    echo \"Iniciando como TrayIcon...\";
    cd \"\$PW_HOME\"


i=0;
j=8;
while [ \$i != \"3\" ]
do

if [ -e /dev/ttyUSB\$i ]; then
       echo Criando link simbolico para USB-Serial.
       ln -sf /dev/ttyUSB\$i /dev/ttyS\$j
	   stty -F /dev/ttyUSB\$i -brkint -icrnl -imaxbel -opost -onlcr -isig -icanon -iexten -echo -echoe -echok -echoctl;max=0;min=0;time=0;line=0 
       j=\$[j+1]; 
fi

    i=\$[i+1];

done
    rm -f output.log
    java -noverify -Djava.library.path=\$PW_DLL -cp \"\$PW_CLASSPATH\":\"\$WEBSERVER_CLASSPATH\"  br.com.sms.powerview.tray.SmsTrayIcon \$DEBUG & 
        
    echo \"SMS Power View iniciado com sucesso.\";
fi

}

#Exibe status com o power
nobreak(){
if [ -e SMSPowerView.tmp ]; 
  then
      java -noverify -DJAVA_SMS=\"\$PW_HOME\"/xml/ -cp \"\$CONSOLE_CLASSPATH\" br.com.sms.powerview.script.Script &  
      sleep 1;
  fi
}


#Função stop do powerview
stop(){
if [ -e \"\$PW_HOME\"/SMSPowerView.tmp ] 
then
	echo \"Parando o aplicativo: \$NOME_APP\";
	pid=\`cat \"\$PW_HOME\"/xml/pid.txt\`
	kill \$pid;
	echo \"SMS Power View parado com sucesso.\";
else
	echo \"\";
	echo \"O \$NOME_APP não está em execução.\";
	echo \"\";
fi
}


#Função que testa as portas utilizadas pelo PowerView
testecomunicacao(){
cd \"\$PW_HOME\"

if [ -e \"\$PW_HOME\"/SMSPowerView.tmp ] 
then
	echo \"\";
    echo \"Erro: O \$NOME_APP está em execução.\";
	echo \"\";
else
	java -noverify -DJAVA_SMS=\"\$PW_HOME\"/xml/ -cp \"\$PW_CLASSPATH\" br.com.sms.powerview.testecomm.novo.TesteService	
fi	
}

#Função console do powerview
console(){
cd \"\$PW_HOME\"

if [ -e \"\$PW_HOME\"/SMSPowerView.tmp ] 
then
	java -noverify -cp \"\$CONSOLE_CLASSPATH\" br.com.sms.powerview.dos.SmsConsole
else
	echo \"\";
	echo \"Erro: É necessário inicializar o sistema antes de utilizá-lo no modo console.\";
	echo \"\";
fi

}

#Função restart do powerview
restart(){
if [ -e \"\$PW_HOME\"/SMSPowerView.tmp ] 
then

	echo \"Reiniciando o \$NOME_APP\";
	stop ;
	sleep 1s;
	start ;
else
	echo \"O \$NOME_APP não está em execução.\";
	start ;
fi
   
}

#Função status do powerview
status(){
if [ -e \"\$PW_HOME\"/SMSPowerView.tmp ]
then
    echo \"\";
    echo \"Status do SMS Power View: Em execução.\";
    nobreak;
    echo \"\";
else
    echo \"\";
    echo \"Status do SMS Power View: Não está em execução.\";
    echo \"\";
fi
}

#Função que exibe a versão do powerview
version(){
	java -noverify -Djava.library.path=\$PW_DLL -cp \"\$PW_CLASSPATH\":\"\$WEBSERVER_CLASSPATH\"  br.com.sms.powerview.common.Constantes
}

#Exibe Ajuda
exibirAjuda(){
	     clear;
	     echo \"Sintaxe:\";
	     echo \"./powerview [OPÇÕES...] \";
	     echo \"\";
	     echo \"Opções do Aplicativo:\";
	     echo \"\";
	     echo \"start 				Inicializar o \$NOME_APP.\";
	     echo \"stop 				Parar o \$NOME_APP.\";
	     echo \"status				Exibir o status do \$NOME_APP.\";
	     echo \"restart				Reiniciar o \$NOME_APP\";
	     echo \"-c, --console			Exibir o \$NOME_APP no console.\";
	     echo \"-v, --version			Exibir a versão do \$NOME_APP\";
	     echo \"-t, --test			Realizar o teste de comunicação das portas.\"
	     echo \"-g, --gui			Inicializar o \$NOME_APP no modo gráfico.\";
	     echo \"				[start/restart]\";
	     echo \"--no-gui			Inicializar o \$NOME_APP no modo serviço.\";
	     echo \"				[start/restart]\";
	     echo \"-d, --debug			Inicializar o \$NOME_APP com debug.\";
	     echo \"				[start/restart]\";
	     echo \"--no-debug			Inicializar o \$NOME_APP sem debug.\";
	     echo \"				[start/restart]\";
	     echo \"\";
	     echo \"Exemplo de uso: ./powerview start -g --no-debug  \";
	     echo \"\";
}


#Função de help para o powerview
ajuda(){
    if [ \"\$ATIVO\" = \"1\" ];
      then
	 if [ \"\$OPCAO\" = \"\" ];
            then
		start;
         else
		exibirAjuda;
	 fi
      else	
        exibirAjuda;
    fi
}


if [ ! -e \$1 ];
  then
    OPCAO=\$1;
fi

if [ ! -e \$2 ];
  then
    MODIFICADOR1=\$2;
fi

if [ ! -e \$3 ];
  then
    MODIFICADOR2=\$3;
fi

if [ ! -e \$4 ];
  then
    ERRO=1;
fi

if [ \"\$OPCAO\" != \"start\" -a \"\$OPCAO\" != \"restart\" ];
then
if [ ! -e \$2 ];
  then
    ERRO=1;
fi
fi

if [ ! -e \$ERRO ];
then
  ajuda;
else
  if [ \"\$MODIFICADOR1\" = \"-g\" -o \"\$MODIFICADOR1\" = \"--gui\" -o \"\$MODIFICADOR2\" = \"-g\" -o \"\$MODIFICADOR2\" = \"--gui\" ]; 
    then
      if [ \"\$MODIFICADOR1\" = \"\$MODIFICADOR2\" -o \"\$MODIFICADOR1\" = \"-g\" -a \"\$MODIFICADOR2\" = \"--gui\" -o \"\$MODIFICADOR1\" = \"--gui\" -a \"\$MODIFICADOR2\" = \"-g\" ];
        then
           echo \"\";
	   echo \"Parâmetros inconsistentes.\";
           echo \"\";
	   ERRO=1;
	   INCOSISTENCIA=0;
        else 
           GUI=1;
      fi
      
  fi

  if [ \"\$MODIFICADOR1\" = \"--no-gui\" -o \"\$MODIFICADOR2\" = \"--no-gui\" ]; 
    then
      if [ \"\$MODIFICADOR1\" = \"\$MODIFICADOR2\" -o \"\$MODIFICADOR1\" = \"-g\" -o \"\$MODIFICADOR2\" = \"-g\" -o \"\$MODIFICADOR1\" = \"--gui\" -o \"\$MODIFICADOR2\" = \"--gui\" ];
        then
           echo \"\";
	   echo \"Parâmetros inconsistentes.\";
           echo \"\";
	   ERRO=1;
	   INCOSISTENCIA=0;	   
        else 
           GUI=0;
      fi
  fi

  if [ \"\$MODIFICADOR1\" = \"--no-debug\" -o \"\$MODIFICADOR2\" = \"--no-debug\" ]; 
    then
     if [ \"\$MODIFICADOR1\" = \"\$MODIFICADOR2\" -o \"\$MODIFICADOR1\" = \"-d\" -o \"\$MODIFICADOR2\" = \"-d\" -o \"\$MODIFICADOR1\" = \"--debug\" -o \"\$MODIFICADOR2\" = \"--debug\" ];
        then
           echo \"\";
	   echo \"Parâmetros inconsistentes.\";
           echo \"\";
	   ERRO=1;
	   INCOSISTENCIA=0;
        else 
           DEBUG=\"\";
      fi
  fi


  if [ \"\$MODIFICADOR1\" = \"-d\" -o \"\$MODIFICADOR1\" = \"--debug\" -o \"\$MODIFICADOR2\" = \"-d\" -o \"\$MODIFICADOR2\" = \"--debug\" ]; 
    then
      if [ \"\$MODIFICADOR1\" = \"\$MODIFICADOR2\" -o \"\$MODIFICADOR1\" = \"-d\" -a \"\$MODIFICADOR2\" = \"--debug\" -o \"\$MODIFICADOR1\" = \"--debug\" -a \"\$MODIFICADOR2\" = \"-d\" ];
        then
           echo \"\";
	   echo \"Parâmetros inconsistentes.\";	
           echo \"\";
	   ERRO=1;
	   INCOSISTENCIA=0;
        else
        DEBUG=\"DEBUG\";
      fi
    fi

if [ ! -e \$MODIFICADOR1 ];
  then
if [ \"\$MODIFICADOR1\" != \"-g\" -a \"\$MODIFICADOR1\" != \"--gui\" -a \"\$MODIFICADOR1\" != \"-d\" -a \"\$MODIFICADOR1\" != \"--debug\" -a \"\$MODIFICADOR1\" != \"--no-gui\" -a \"\$MODIFICADOR1\" != \"--no-debug\" ];
then
   ERRO=1;
fi
fi

if [ ! -e \$MODIFICADOR2 ];
  then
if [ \"\$MODIFICADOR2\" != \"-g\" -a \"\$MODIFICADOR2\" != \"--gui\" -a \"\$MODIFICADOR2\" != \"-d\" -a \"\$MODIFICADOR2\" != \"--debug\" -a \"\$MODIFICADOR2\" != \"--no-gui\" -a \"\$MODIFICADOR2\" != \"--no-debug\" ];
then
   ERRO=1;
fi
fi



if [ -e \$GUI ];
then
   if [ \"\$GUI_DEFAULT\" != \"0\" ];
     then
         GUI=1;
     else
         GUI=\$GUI_DEFAULT;
   fi
fi

if [ -e \$DEBUG ];
then
    if [ \"\$DEBUG_DEFAULT\" != \"0\" ];
      then
          DEBUG=\"DEBUG\";
    fi
fi

if [ -e \$ERRO ];
then

  if [ -e SMSPowerView.tmp ];
    then
      java -noverify -Djava.library.path=.:libs/ -cp \"\$PW_CLASSPATH\"  br.com.sms.powerview.util.VerificaArquivoTemp >> /dev/null &
      sleep 1;
  fi


#Verifica o parâmetro recebido
  case \$OPCAO in
    start) start;;
    stop) stop;;	
    restart) restart;;
    -c) console;;
    --console) console;;
    status) status;;
    -v) version;;
    --version) version;;
    -t) testecomunicacao;;
    --test) testecomunicacao;;	
    *) ajuda;;
  esac
else
  if [ \"\$INCOSISTENCIA\" != \"0\" ]
     then
        ajuda;
  fi
fi
fi" > "$LOCAL_INSTALACAO"/powerview
 chmod +xs "$LOCAL_INSTALACAO"/powerview
 iniciar_app
}

iniciar_app(){
 echo ""
 echo "O SMS PowerView Linux encontra-se em $LOCAL_INSTALACAO e esta pronto para executar. Para tal, basta executar o script powerview"
 echo ""
}

clear
local_instalacao
