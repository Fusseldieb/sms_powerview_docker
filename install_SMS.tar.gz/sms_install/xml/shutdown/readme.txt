Execute o aplicativo shut.exe

Ele gerar� dois arquivos de log:
1) sms_office.log -> Guarda data,hora e nomes dos documentos office que foram fechados
2) sms_geral.log -> Guarda dat,hora e nomes dos processos ...

Obs.: O arquivo path.sht cont�m o caminho dos arquivos de log. N�o esquecer de manter no final a barra invertida '\'.